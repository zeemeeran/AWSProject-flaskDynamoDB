from flask import Flask

# initializing Flask object
application = Flask(__name__)
app = application

import routes 